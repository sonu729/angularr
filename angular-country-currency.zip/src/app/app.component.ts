import { Component } from '@angular/core';
import {Http} from '@angular/http'
import {map} from 'rxjs/operators'
@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Angular';
  httpdata;
  countryname;
  currency;
  constructor(private http:Http){}
  find(){
this.http.get("https://restcountries.eu/rest/v2/name/"+this.countryname).pipe(map(response=>response.json())).subscribe((data)=>{this.store(data[0].currencies[0].name)})



  }
  store(data){
    this.currency=data
    
  }
 
}
